# Lantern VNC — free VNC client for Mac

**Current preview: 1.1.0-preview.5 · Apple Silicon · macOS 13+**

A free native VNC client for Apple Silicon Macs, built with AppKit and Metal.
Use it for an occasional remote task or regular direct access to your existing VNC server.
Connect directly to a TightVNC server, view its desktop, and control it with
your Mac's keyboard and mouse. No browser, account, subscription, or license
key is required. This version has no expiry, trial clock, license check, or
paid feature unlock. Optional tips and feedback never affect access.

**Preview candidate:** this update replaces the 1.0 display/navigation model,
which had large-desktop scaling and edge-navigation issues. The new controls
are implemented locally, but physical external-display transitions and the
complete manual hardware matrix have not been verified. Treat this as a
preview, not a fully checked stable release.

[Project website](https://py-killer.github.io/lantern-vnc/) ·
[Mac VNC client guide](https://py-killer.github.io/lantern-vnc/mac-vnc-client.html) ·
[Occasional-access guide](https://py-killer.github.io/lantern-vnc/occasional-vnc-access.html) ·
[Source repository](https://github.com/py-killer/lantern-vnc) ·
[Community and feedback](COMMUNITY.md) ·
[Wiki](docs/wiki/Home.md) · [Changelog](CHANGELOG.md) ·
[Release checklist](docs/RELEASE_CHECKLIST.md) ·
[Preview 5 test results](docs/TEST_RESULTS-1.1.0-preview.5.md) ·
[Earlier Preview 4 results](docs/TEST_RESULTS-1.1.0-preview.4.md)

## Open the app

Requirements: macOS 13 or later and an Apple Silicon Mac (M1 through M5 and
other compatible Apple Silicon models). The app is an arm64 build. It does
not support Intel Macs. Python, Node.js, CMake, and Xcode are not required to
run the supplied app.

1. Extract `Lantern-VNC-macOS.zip` and move `Lantern VNC.app` to Applications
   or another folder you control.
2. Open `Lantern VNC.app`. This development build is ad hoc signed and has
   not been Apple-notarized. If macOS blocks it, use Finder's contextual
   **Open** command, or review the app in **System Settings → Privacy &
   Security → Open Anyway** if that option appears. Only approve a copy from
   a source you trust. Do not disable Gatekeeper system-wide.
3. If macOS requests access to the local network, allow it so the app can
   reach your server.
4. Choose **Find…** beside Server to search your local Wi-Fi or Ethernet
   network. A lone result is selected automatically; otherwise select one.
   Confirm or edit its alias and choose **Save Computer**. You can also enter
   a known host and TCP port manually. The usual port is `5900`; the field
   takes a TCP port, not a VNC display number.
5. Enter the **VNC password configured in TightVNC** and choose **Connect**.
   **Remember password** is off for a new endpoint. Enable it only if you want
   the password saved in macOS Keychain after a successful connection.

Classic VNC password authentication uses only the first eight password bytes.
An account password for Windows or macOS is not necessarily your VNC password.
The app does not require a Lantern account.

**Find…** checks only the selected port on private IPv4 Wi-Fi/Ethernet
interfaces. It respects the subnet mask and limits larger networks to the
local `/24` neighborhood. It reads the VNC greeting without authenticating
or sending credentials. Search can be canceled or retried; a result confirms
a VNC greeting, not that your password or remote-control permissions work.
VPN interfaces, IPv6, Bonjour, and other ports are not automatically searched.
Use a manual address for those setups or when no result appears.

## Use the remote desktop

New server addresses/ports start in **Fit to Window**, showing the whole
desktop. If text is too small, choose **Auto (Readable)** or a larger zoom,
then use the visible scroll bars or **Hand** to navigate. Lantern remembers
the zoom mode, including custom pinch scale, for each host and port across
restarts. Pan positions are not remembered. These controls change your local
view; they never change the server's resolution.

| Control | Behavior |
| --- | --- |
| **Fit to Window** | Default for a new endpoint. Shows the whole desktop with its aspect ratio preserved. Text may be small on a large remote desktop. |
| **Auto (Readable)** | Uses `max(100%, min(Fit zoom, 200%))` in drawable/backing pixels. A large 5K desktop stays at 100% and can be navigated with scroll bars or Hand. |
| **50%, 75%, 100%, 125%, 150%, 200%** | Explicit local zoom. At 100%, one remote pixel maps to one Metal drawable/backing pixel. macOS scaled display modes may resample the final panel image. |
| **Pinch** | Sets a custom local zoom between 10% and 400%. |
| **Hand** | Drag, scroll, or use arrow keys to move the local view. Press Escape or turn Hand off to resume remote control. |
| **Native scroll bars** | Stay visible on each axis where the image is larger than the viewport. |
| **Sidebar button / Control–Command–S** | Hide or show connection settings to make more room for the desktop. |

With Hand off, click inside the remote image to type and control the pointer;
normal wheel/trackpad scrolling is sent to the remote computer. Hand is a
local navigation mode and does not send remote clicks, typing, or wheel
input.

**Control–Command–+ / −** zoom in/out; **Control–Command–0** selects 100%.
**Control–Command–F** toggles full screen, and **Command–K** connects or
disconnects. The sidebar is hidden on entering full screen and restored when
leaving it.

**View only** suppresses keyboard, pointer, and clipboard changes sent to the
server. Optional **Map Command to Control** helps with Windows/Linux
shortcuts. **Ctrl–Alt–Del**, **Clipboard**, and **Refresh screen** remain
explicit toolbar actions. **Share clipboard text** enables optional two-way
text transfer.

See [Display and navigation](docs/wiki/Display-and-Navigation.md) for the
viewing model and [Troubleshooting](docs/wiki/Troubleshooting.md) for common
connection, display, and input problems.

**Wi-Fi · high quality** is the default picture preset for a new endpoint.
It requests the same Tight JPEG level 8 as **Balanced · fast LAN**, with
moderate compression level 3 instead of 1. This can trade more server CPU
for fewer transferred bytes; it does not guarantee faster performance.
**Fast · lower bandwidth** requests JPEG level 5 and compression 1.
**Lossless · sharp text** keeps compression enabled at level 1 and disables
JPEG for exact decoded pixels. JPEG-enabled presets can introduce text
artifacts; the coarse levels are not quality percentages.

Picture presets are saved per host and port and apply on the next connection.
On the first upgrade, the former global picture preset is copied to existing
devices; later changes are independent for each endpoint. Performance depends
on the server, remote screen size, and network. The renderer uses Metal and
the JPEG decoder uses Apple Silicon SIMD; there is no automatic bandwidth or
quality adaptation.

Preview 5 copies and uploads changed parts of the decoded desktop instead
of repeatedly copying the entire image for small updates. Each display
buffer keeps the changes it still needs. Queued keyboard and pointer input
can also be sent while an incomplete screen update waits for more data.
These local changes preserve decoded pixels, picture presets, and server
resolution; they do not change VNC compression or guarantee faster Wi-Fi.
Full-screen changes still require full-image work. The recorded copy
benchmark measures local CPU work, not network or end-to-end performance.

Save up to three device profiles to switch between your usual servers. Device
settings are stored locally on your Mac. The finder saves a device when you
confirm its alias. Choose **Rename…** to change a saved name or **Save…** for
a manually entered device; a successful manual connection also saves it when
a slot is available, using the server's desktop name. Passwords are stored separately
in macOS Keychain only when you opt in. Uncheck **Remember password** to
delete the saved password for that host and port; **Remove** deletes the
selected profile and its saved password. One remote session is active at a
time. A full saved list still permits a one-off connection.

Startup, reconnect, and routine Keychain reads, saves, and deletions do not
open a Mac-password approval dialog. If a saved password needs approval,
Lantern offers **Use saved password…**; only clicking that optional button
may ask for your **Mac login password**, which is separate from the remote
VNC password. You can always enter the VNC password manually instead.
Unavailable Keychain access reports a hint or error; the app keeps its
storage protections and does not fall back to plaintext or reset Keychain.

## Optional support and feedback

Choose the route that fits your message:

- [Report a bug](https://github.com/py-killer/lantern-vnc/issues/new?template=bug_report.yml), even if you cannot reproduce it yet.
- [Suggest an idea](https://github.com/py-killer/lantern-vnc/issues/new?template=feature_request.yml) or [ask a question](https://github.com/py-killer/lantern-vnc/issues/new?template=question.yml).
- [Share thanks or a working setup](https://github.com/py-killer/lantern-vnc/issues/new?template=thanks.yml).
- [Use website feedback without GitHub sign-in](https://py-killer.github.io/lantern-vnc/#feedback).

The app's **Help → Send Feedback…** opens the website feedback form in your
browser. GitHub issue forms are another option and may require a GitHub
sign-in; that account is never required to run Lantern VNC. The website form sends feedback only when you submit it
and shows a receipt after a successful submission. Read its privacy notice
before sending. A failed or offline submission has not reached maintainers.
Neither route is required to use the app, and neither promises an instant
reply. Leave passwords, private server details, and personal desktop data
out of reports. See [the community guide](COMMUNITY.md) for how reports are
handled and [the security policy](SECURITY.md) for possible vulnerabilities.

Use **Help → Save Feedback…** to write a local text file containing your notes,
app version, release channel/build, macOS version, GPU name, and renderer name. The app does not
automatically add a server address, password, clipboard contents, or network
credentials. Review your own notes before sharing the file. Saving feedback
does not send it anywhere.

The support command opens the website's
[support section](https://py-killer.github.io/lantern-vnc/#support). Tipping is
not enabled: the optional interest poll only asks whether you find Lantern
useful and would consider donating. Clicking it records your answer and
shows thanks; it makes no payment or pledge. Every feature remains free.

## Privacy and network security

Lantern VNC connects directly to the selected server. It has no account
service, analytics, cloud relay, or licensing server. Saved server settings
stay in the app's local preferences. VNC passwords stay in process memory
for connection setup unless you explicitly enable **Remember password**.
Remembered passwords use the classic macOS login Keychain with Keychain
synchronization disabled; plaintext passwords are never written to
preferences or device profiles, or automatically included in feedback exports. This is not a claim that
Keychain items are excluded from every backup. Keychain errors leave manual
password entry available. **Find…** makes bounded, user-requested local
connections solely to check VNC greetings. Enabling
clipboard sharing transfers clipboard text between your Mac and the server;
leave it disabled if you do not want that transfer.

The project website is separate from the desktop app. Its explicit feedback
form sends the selected feedback kind, message, and random visitor/event
identifiers to the website service. Its privacy notice explains those fields
and optional aggregate website counts, including how to stop automatic
counts. Website collection does not add analytics to the app, and visiting
the website or submitting feedback is not required for a VNC connection.

This build does **not encrypt the VNC transport** and does not implement an
SSH tunnel. Use it on a network you trust or through a separately established
VPN/SSH tunnel. Do not expose an unencrypted TightVNC service directly to the
internet. The server decides whether a connection permits remote control.

## Troubleshooting

- **Cannot connect / connection refused:** confirm TightVNC Server is running,
  the server's current address is correct, its VNC listening port is `5900`
  (or the value you entered), and the firewall allows that connection.
- **Connection timed out:** put both devices on a reachable LAN or VPN. Guest
  Wi-Fi isolation and a changed server address can prevent access.
- **Find… returns no results:** check local-network permission, Wi-Fi/Ethernet,
  and the selected port, then retry. Discovery does not search VPNs, IPv6, or
  every port; enter a known server address manually when needed.
- **Authentication failed:** check the TightVNC VNC password and whether the
  server offers standard VNC password authentication. This build does not
  provide RealVNC cloud login or enterprise identity authentication. A wrong
  password does not establish that the server address or port is wrong.
- **Connected but input does nothing:** turn off Hand, disable View only, and confirm the
  server account/password grants control. A view-only TightVNC password
  remains view-only even when the app's checkbox is off.
- **Desktop edges are out of view:** use the visible scroll bars or Hand. Use
  Fit to Window for an overview, or a larger explicit zoom for readable text.
- **Screen looks stale:** request a full update with Refresh screen.
- **Updates feel slow:** compare Wi-Fi and Balanced after reconnecting if the
  server may be CPU-limited. Fit changes the local view, not the amount of
  remote desktop requested. Local copy improvements cannot fix a blocked or
  unreliable network path.

This is a focused desktop viewer, with no audio, file transfer, printing,
recording, cloud address book, or unattended relay service. It does not aim
to duplicate every feature of a commercial remote-access suite. Remote
framebuffers are limited to 16,384 pixels per axis and 256 MiB total memory.

### Preview verification limits

The fixed Metal viewport, shared render/input transform, explicit zoom, and
Hand navigation are implemented in this candidate. Automated geometry,
protocol, and synthetic native GPU checks do not replace manual checks on a
real server and physical displays. Moving between 1× external and 2× Retina
displays, external-monitor disconnect/reconnect, macOS scaled display modes,
and the full manual resolution/window matrix remain unverified. See the
[release checklist](docs/RELEASE_CHECKLIST.md); unchecked cases are not passes.

## Build from source

The matching source is in `Lantern-VNC-source.zip`. It includes the Swift
application, C bridge, complete LibVNCServer 0.9.15 and libjpeg-turbo 3.2.1
source trees, original license notices, tests, build scripts, wiki, and
community guidance.

Building requires an Apple Silicon Mac, the Xcode command-line tools
(`xcrun clang` and `xcrun swiftc`), and CMake 3.16 or later available on PATH.
No dependency download is required when using the complete source archive.
From the extracted source folder:

```sh
./scripts/build-deps.sh
./scripts/build-app.sh
open "build/artifacts.noindex/Lantern VNC.app"
```

If CMake is installed outside PATH, set `CMAKE_BIN` to its executable. The
build uses arm64, macOS 13 as the deployment target, static LibVNCClient and
libjpeg-turbo, and the macOS system zlib. The icon is included; regenerate
its original vector artwork with:

```sh
xcrun swift -module-cache-path build/module-cache scripts/make-icon.swift
```

Run the local mock-server integration tests with Python 3:

```sh
./tests/run-tests.sh
TEST_SANITIZE=1 ./tests/run-tests.sh
./tests/run-display-tests.sh
./tests/run-app-ui-tests.sh
./tests/run-network-discovery-tests.sh
./tests/run-password-tests.sh
./tests/run-frame-update-tests.sh
FRAME_TEST_SANITIZE=1 ./tests/run-frame-update-tests.sh
```

The protocol tests cover raw/Tight/JPEG decoded pixels, compression and JPEG
negotiation, remote resizing, input/clipboard messages, view-only suppression,
authentication failures, cancellation, connection errors, and repeated cleanup.
The display test script checks
viewport geometry and an owned offscreen native window with synthetic
frames and events. It does not send input to a real remote desktop. If Metal
or WindowServer is unavailable, that native harness reports exit 77 rather
than a passing result.

The frame-update tests reconstruct pixels against an independent oracle
through dirty updates, coalescing, resizing, stale display buffers, and
concurrent receives. Their 5K copy benchmark reports CPU timing and byte
counts separately from GPU or network performance. Mock protocol tests also
check queued input during fragmented screen and capability messages.

Physical display switching, real-server usability, and manual gestures need
the separate [release checklist](docs/RELEASE_CHECKLIST.md). A successful
login to a real TightVNC server still requires its password and a reachable
network.

To rebuild the app and create the app/source distribution archives (also
requires Python 3 for source staging):

```sh
./scripts/package.sh
```

The package script writes to `../outputs` by default; an absolute output
directory can be passed as its first argument. It verifies the ad hoc code
signature and bundles the license notices. Ad hoc signing permits local
integrity checks and is not Apple Developer ID signing or notarization.
Apple Developer ID signing and Apple notarization are pending. This package
uses ad hoc signing, and macOS may require you to approve opening it.

## Community

Start with [community and feedback](COMMUNITY.md) or the
[web wiki](https://py-killer.github.io/lantern-vnc/wiki/). Maintainers and
configured maintenance automation may investigate real reports, fix issues,
and reply directly in GitHub. Maintenance is best effort, without a promised
response time. See [Contributing](CONTRIBUTING.md), the
[code of conduct](CODE_OF_CONDUCT.md), and the [security policy](SECURITY.md).
Issues and pull requests are public; review notes and screenshots before
sharing. [Unpublished promotion drafts](docs/PROMOTION.md) document current
claims and posting venues; they are not external posts.

## License and acknowledgments

Lantern VNC's application code, wrapper, scripts, and original icon artwork
are provided under GNU GPL version 2 or, at your option, any later version.
See `LICENSE` and `THIRD_PARTY_NOTICES.md`. There is no warranty. Keep the
matching source archive and licenses available when redistributing the app.
The free current version does not depend on donations or a subscription.

This software is based in part on the work of the Independent JPEG Group.
