# Getting started

[Wiki home](Home.md) · [Display controls](Display-and-Navigation.md) · [Troubleshooting](Troubleshooting.md)

## What you need

- An Apple Silicon Mac running macOS 13 or later. The supplied app is an arm64 build; Intel Macs are not supported.
- A running VNC server, its TCP port, and its VNC password if authentication is enabled. Find a nearby server in the app or enter its reachable address manually.
- A trusted local network, or a VPN/SSH connection that you establish separately. This build does not encrypt the VNC transport.

The downloadable app does not need Xcode, Python, CMake, or a Lantern account. Development tools are needed only to build from source.

## Open and connect

1. Get the Mac ZIP from the [project website](https://py-killer.github.io/lantern-vnc/) and extract it. Move **Lantern VNC.app** to Applications or another folder you control.
2. Open the app. Current builds are ad hoc signed and not Apple-notarized. If macOS blocks a copy you trust, use Finder's contextual **Open** command or review the available **Open Anyway** option in Privacy & Security. Do not disable Gatekeeper system-wide.
3. If macOS asks for local network access, allow it so Lantern can reach your server.
4. Set the TCP port, usually `5900`, and choose **Find…** beside Server. If one server is found, it is selected automatically. Confirm or edit its alias and choose **Save Computer** to add it to your device list immediately. If several are found, select the one you want first. You can enter a known address manually instead. A server on display `:1` often uses `5901`; enter its actual TCP port, not the display number.
5. Enter the password configured for VNC on the server and choose **Connect**. A Windows or macOS account password is not necessarily the VNC password. Classic VNC authentication uses the first eight password bytes. **Remember password** is off for a new endpoint; enable it only if you want macOS Keychain to save the password after a successful connection.
6. New server addresses/ports start with **Fit to Window** and **Wi-Fi · high quality**. Fit shows the whole desktop. If text is too small, choose **Auto (Readable)** or a larger zoom, then use visible scroll bars or **Hand** to move the local view. Turn Hand off and click the remote image to send keyboard and pointer input.

If the connection fails, check the [troubleshooting guide](Troubleshooting.md). Repeatedly trying a different password cannot fix an unreachable server or a blocked port.

Once connected, **RTT** appears below the connection status and refreshes once a second. It is a passive TCP round-trip estimate, not keyboard-to-screen delay. **RTT unavailable** means no usable estimate; **idle** means no traffic-counter change was observed for five seconds. Hover over it for the explanation, including local port-forwarding limits. See [Read network RTT](Display-and-Navigation.md#read-network-rtt).

## Find a local server

Search checks one selected TCP port on active private IPv4 Wi-Fi/Ethernet interfaces. Choose the network in the picker if more than one is available. It respects the subnet mask; for a subnet larger than `/24`, only the local `/24` neighborhood is searched. You can cancel, retry, or select a result as it appears. The search reads a VNC greeting and sends no authentication or credentials.

Discovery does not search VPN interfaces, IPv6, Bonjour, other ports, or public IPv4 networks. No result does not mean no server exists: check local-network permission, the port, and whether the server is reachable, or use its address manually. A result does not establish the server's identity, password, or control permissions.

## Save your usual devices

The finder saves a named device when you confirm its alias. Use **Rename…** for an existing saved device, or **Save…** for a manually entered connection. A successful connection also saves a device when a slot is available, using the alias from the picker or the server's desktop name for a new profile. Lantern can save up to three devices and keeps one session active at a time. Choose a saved device to restore its connection settings; use **Remove** to free a saved slot.

Passwords are not saved in device profiles. If you enable **Remember password**, Lantern attempts to save the password separately in the classic macOS login Keychain after a successful connection. Keychain synchronization is disabled. Uncheck the box to request deletion; **Remove** also requests removal of that profile's saved password. If an operation fails, its inline message explains the failure, and inaccessible old items remain unchanged. A full saved list does not prevent a one-off connection using the Server and Port fields.

Every Keychain read, save, and deletion is noninteractive, with no authentication dialog or approval button. A failed save turns **Remember password** off. Manual VNC password entry remains available, with no plaintext fallback or Keychain security reset. Ad hoc signed app updates can lose access to earlier saved items; reliable cross-update persistence has not been verified for this preview.

## Keep your viewing preferences

The app reopens at its last normal window size and position. If the saved monitor is unavailable, it recovers placement on an available screen. This local window geometry does not change the server's resolution.

Lantern remembers zoom mode—including a custom pinch scale—and picture preset for each host and port, including after restarting the app. Pan positions are not remembered. Picture changes apply on the next connection. On the first upgrade, existing devices inherit the previous global picture preset once; afterward their settings are independent.

**Wi-Fi · high quality** requests the same JPEG level as Balanced with moderate compression that may use more server CPU. Choose **Lossless · sharp text** when JPEG artifacts are unwanted; it still uses compressed transfer. Presets do not change the server's resolution, and no preset guarantees the fastest result on every network. See [Display controls](Display-and-Navigation.md) for the exact settings.

## Before using clipboard sharing

**Share clipboard text** is optional. When enabled, text can move between your Mac and the server. Leave it off if you do not want that transfer. **View only** suppresses keyboard, pointer, and clipboard changes sent to the server; the server can also independently restrict a connection to viewing.

Choose **Disconnect** when finished. **Command–K** connects or disconnects, **Control–Command–F** toggles full screen, and **Control–Command–S** shows/hides the connection sidebar. See the [display guide](Display-and-Navigation.md) for zoom and Hand controls.

These controls are implemented in 1.1.0-preview.6. It remains a preview while physical display transitions and the manual hardware matrix are unverified.
